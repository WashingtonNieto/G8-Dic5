package com.g8Dic5.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class G8Dic5Application {

	public static void main(String[] args) {
		SpringApplication.run(G8Dic5Application.class, args);
	}

}
